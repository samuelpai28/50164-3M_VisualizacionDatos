# Dashboard de Ventas - Coquito Amarillo

## 📊 Descripción

Dashboard interactivo estilo Power BI para análisis de ventas por productos y segmentaciones. Incluye visualizaciones con colores condicionales (rojo, verde, amarillo) según el rendimiento.

## 🚀 Cómo Usar

### Opción 1: Abrir directamente en el navegador

1. Asegúrate de que los siguientes archivos estén en la misma carpeta:
   - `dashboard_ventas.html`
   - `generate_dashboard_data.js`
   - `df_ventas_limpiado.csv`

2. Abre `dashboard_ventas.html` en tu navegador (Chrome, Firefox, Edge)

### Opción 2: Actualizar datos

Si necesitas regenerar los datos desde el CSV:

```bash
python generate_dashboard_data.py
```

Luego abre `dashboard_ventas.html` en tu navegador.

## 📁 Archivos del Dashboard

- **dashboard_ventas.html**: Dashboard principal (HTML + CSS + JavaScript)
- **generate_dashboard_data.py**: Script Python para generar datos
- **generate_dashboard_data.js**: Datos generados en formato JavaScript
- **df_ventas_limpiado.csv**: Dataset limpio con todas las transformaciones

## 🎨 Características

### Visualizaciones Incluidas

1. **Tarjetas KPI** (5 indicadores clave):
   - Ventas Totales
   - Utilidad Total
   - Margen Promedio (con color condicional)
   - Total Órdenes
   - Ticket Promedio

2. **Gráficos de Análisis**:
   - Ventas por Producto (Barras)
   - Distribución por Categoría (Donut)
   - Ventas por Canal (Barras)
   - Ventas por Ciudad (Barras horizontales)
   - Segmentación de Clientes (Pie)
   - Ventas por Rango de Precio (Barras)

3. **Tabla Detallada**:
   - Ranking de productos con análisis completo
   - Incluye: Ventas, Utilidad, Margen %, Cantidad, Órdenes
   - Badges de estado (Excelente/Bueno/Bajo) según margen

### Colores Condicionales

El dashboard usa un sistema de colores para indicar rendimiento:

- 🟢 **Verde (#10b981)**: Excelente rendimiento
  - Margen ≥ 40%
  - Ventas altas
  - Estado "Excelente"

- 🟡 **Amarillo (#f59e0b)**: Buen rendimiento
  - Margen entre 25% y 39%
  - Ventas medias
  - Estado "Bueno"

- 🔴 **Rojo (#ef4444)**: Rendimiento bajo
  - Margen < 25%
  - Ventas bajas
  - Estado "Bajo"

- 🔵 **Azul (#3b82f6)**: Información general
  - Canales
  - Categorías
  - KPIs informativos

## 📊 Métricas Calculadas

### Por Producto
- Ventas totales (Ingreso)
- Utilidad total
- Margen de utilidad (%)
- Cantidad vendida
- Número de órdenes
- Categoría

### Por Segmentación
- **Categorías**: Electrónica, Muebles, Accesorios
- **Canales**: Web, App, Redes
- **Ciudades**: Bogotá, Medellín, Barranquilla, Bucaramanga, Cali
- **Segmentos de Cliente**: Muy Satisfecho, Satisfecho, Neutral, Insatisfecho, Muy Insatisfecho
- **Rangos de Precio**: Alto, Medio, Bajo, Muy Bajo

## 🔧 Requisitos

- Navegador web moderno (Chrome, Firefox, Edge, Safari)
- Conexión a Internet (para cargar Chart.js desde CDN)
- Python 3.x (solo si necesitas regenerar datos)

## 📝 Notas

- Los datos se cargan automáticamente desde `generate_dashboard_data.js`
- El dashboard es completamente interactivo y responsivo
- Los gráficos se actualizan automáticamente al cargar
- Los filtros están preparados para futuras implementaciones

## 🎯 Próximas Mejoras

- Implementar filtros funcionales
- Agregar exportación de datos
- Agregar comparación temporal
- Agregar tooltips más detallados

---

**Versión**: 1.0  
**Fecha**: 2025  
**Empresa**: Coquito Amarillo
