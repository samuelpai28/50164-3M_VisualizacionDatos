# Guía Completa de Métricas y Variables para Dashboard Power BI
## Empresa: Coquito Amarillo - Área de Comercio Electrónico

---

## 1. ANÁLISIS DE VARIABLES DEL DATASET

### 1.1 Variables Cuantitativas
- **OrderID**: Identificador único (int)
- **Cantidad**: Unidades vendidas (int) - *Nota: Puede tener valores negativos (devoluciones)*
- **PrecioUnitario**: Precio por unidad (decimal) - *Nota: Puede tener valores nulos*
- **CostoUnitario**: Costo por unidad (decimal) - *Nota: Puede tener "ERROR_SYS"*
- **CalificacionCliente**: Rating 1-5 (int) - *Nota: Puede tener "ERROR_SYS"*

### 1.2 Variables Cualitativas
- **Ciudad**: Categoría geográfica (Bogotá, Medellín, Cali, Barranquilla, Bucaramanga)
- **Canal**: Canal de venta (Web, App, Redes)
- **Producto**: Nombre del producto (text)
- **Categoria**: Categoría del producto (Accesorios, Electrónica, Muebles) - *Nota: Inconsistencias "Elec" vs "Electrónica"*

### 1.3 Variables Temporales
- **Fecha**: Fecha de la orden (date) - *Nota: Múltiples formatos (YYYY-MM-DD y MM/DD/YYYY)*

---

## 2. PROBLEMAS DE CALIDAD DE DATOS IDENTIFICADOS

### 2.1 Limpieza Requerida en Power Query
1. **Fechas**: Estandarizar formato (algunas en MM/DD/YYYY, otras en YYYY-MM-DD)
2. **Valores Nulos**: 
   - PrecioUnitario vacío (líneas 26, 951, 976, 1000)
   - CostoUnitario con "ERROR_SYS"
3. **Valores Anómalos**:
   - Cantidades negativas (devoluciones - líneas 21, 40, 960, 981, 1000)
   - CalificacionCliente con "ERROR_SYS" (línea 951)
4. **Inconsistencias**:
   - Categoría "Elec" debe ser "Electrónica" (líneas 16, 30, 45, 960, 975, 991)

### 2.2 Transformaciones en Power Query
```M
// Transformaciones recomendadas en Power Query Editor:
1. Cambiar tipo de Fecha a Date
2. Reemplazar "ERROR_SYS" en CostoUnitario por 0 o valor promedio
3. Reemplazar "ERROR_SYS" en CalificacionCliente por 3 (neutral)
4. Reemplazar "Elec" por "Electrónica" en Categoria
5. Filtrar o marcar registros con PrecioUnitario nulo
6. Crear columna "TipoTransaccion" = IF [Cantidad] < 0 THEN "Devolución" ELSE "Venta"
```

---

## 3. COLUMNAS CALCULADAS NECESARIAS

### 3.1 Columnas de Ingresos y Costos
```DAX
// Columna: Ingreso
Ingreso = Ventas[Cantidad] * Ventas[PrecioUnitario]

// Columna: CostoTotal
CostoTotal = Ventas[Cantidad] * Ventas[CostoUnitario]

// Columna: Utilidad
Utilidad = Ventas[Ingreso] - Ventas[CostoTotal]

// Columna: UtilidadPorUnidad
UtilidadPorUnidad = Ventas[PrecioUnitario] - Ventas[CostoUnitario]
```

### 3.2 Columnas de Clasificación Temporal
```DAX
// Columna: Año
Año = YEAR(Ventas[Fecha])

// Columna: Mes
Mes = MONTH(Ventas[Fecha])

// Columna: AñoMes (para agrupaciones)
AñoMes = FORMAT(Ventas[Fecha], "YYYY-MM")

// Columna: Trimestre
Trimestre = "Q" & QUARTER(Ventas[Fecha]) & " " & YEAR(Ventas[Fecha])

// Columna: Semana
Semana = WEEKNUM(Ventas[Fecha], 2) // 2 = Lunes como primer día

// Columna: DíaSemana
DíaSemana = FORMAT(Ventas[Fecha], "dddd")

// Columna: MesNombre
MesNombre = FORMAT(Ventas[Fecha], "MMMM")
```

### 3.3 Columnas de Segmentación
```DAX
// Columna: TipoTransaccion
TipoTransaccion = IF(Ventas[Cantidad] < 0, "Devolución", "Venta")

// Columna: SegmentoCliente (basado en calificación)
SegmentoCliente = 
SWITCH(
    TRUE(),
    Ventas[CalificacionCliente] >= 4.5, "Muy Satisfecho",
    Ventas[CalificacionCliente] >= 3.5, "Satisfecho",
    Ventas[CalificacionCliente] >= 2.5, "Neutral",
    Ventas[CalificacionCliente] >= 1.5, "Insatisfecho",
    "Muy Insatisfecho"
)

// Columna: RangoPrecio
RangoPrecio = 
SWITCH(
    TRUE(),
    Ventas[PrecioUnitario] >= 500, "Alto",
    Ventas[PrecioUnitario] >= 100, "Medio",
    Ventas[PrecioUnitario] >= 50, "Bajo",
    "Muy Bajo"
)
```

---

## 4. MEDIDAS DAX - CATEGORÍA: VENTAS E INGRESOS

### 4.1 Medidas Básicas de Ventas
```DAX
// Ventas Totales
Ventas Totales = 
SUMX(
    Ventas,
    Ventas[Cantidad] * Ventas[PrecioUnitario]
)

// Ventas Totales (Solo Ventas, excluyendo devoluciones)
Ventas Totales Netas = 
SUMX(
    FILTER(Ventas, Ventas[Cantidad] > 0),
    Ventas[Cantidad] * Ventas[PrecioUnitario]
)

// Cantidad Total Vendida
Cantidad Total = 
SUMX(
    FILTER(Ventas, Ventas[Cantidad] > 0),
    Ventas[Cantidad]
)

// Número de Órdenes
Total Órdenes = 
DISTINCTCOUNT(Ventas[OrderID])

// Número de Órdenes (Solo ventas)
Total Órdenes Netas = 
CALCULATE(
    DISTINCTCOUNT(Ventas[OrderID]),
    Ventas[Cantidad] > 0
)
```

### 4.2 Medidas de Ticket Promedio
```DAX
// Ticket Promedio
Ticket Promedio = 
DIVIDE(
    [Ventas Totales Netas],
    [Total Órdenes Netas],
    0
)

// Ticket Promedio por Cliente
Ticket Promedio Cliente = 
DIVIDE(
    [Ventas Totales Netas],
    DISTINCTCOUNT(Ventas[OrderID]),
    0
)
```

---

## 5. MEDIDAS DAX - CATEGORÍA: COSTOS Y RENTABILIDAD

### 5.1 Medidas de Costos
```DAX
// Costo Total
Costo Total = 
SUMX(
    Ventas,
    Ventas[Cantidad] * Ventas[CostoUnitario]
)

// Costo Total Neto (excluyendo devoluciones)
Costo Total Neto = 
SUMX(
    FILTER(Ventas, Ventas[Cantidad] > 0),
    Ventas[Cantidad] * Ventas[CostoUnitario]
)
```

### 5.2 Medidas de Utilidad
```DAX
// Utilidad Total
Utilidad Total = 
[Ventas Totales] - [Costo Total]

// Utilidad Neta (excluyendo devoluciones)
Utilidad Neta = 
[Ventas Totales Netas] - [Costo Total Neto]

// Utilidad Promedio por Orden
Utilidad Promedio Orden = 
DIVIDE(
    [Utilidad Neta],
    [Total Órdenes Netas],
    0
)
```

### 5.3 Medidas de Margen
```DAX
// Margen de Utilidad (%)
Margen % = 
DIVIDE(
    [Utilidad Total],
    [Ventas Totales],
    0
)

// Margen de Utilidad Neta (%)
Margen Neto % = 
DIVIDE(
    [Utilidad Neta],
    [Ventas Totales Netas],
    0
)

// Margen por Unidad
Margen por Unidad = 
AVERAGE(Ventas[UtilidadPorUnidad])
```

---

## 6. MEDIDAS DAX - CATEGORÍA: ANÁLISIS TEMPORAL

### 6.1 Medidas de Comparación Temporal
```DAX
// Ventas Año Anterior
Ventas Año Anterior = 
CALCULATE(
    [Ventas Totales],
    SAMEPERIODLASTYEAR(Ventas[Fecha])
)

// Ventas Mes Anterior
Ventas Mes Anterior = 
CALCULATE(
    [Ventas Totales],
    DATEADD(Ventas[Fecha], -1, MONTH)
)

// Ventas Período Anterior (mismo período del año pasado)
Ventas Período Anterior = 
CALCULATE(
    [Ventas Totales],
    PARALLELPERIOD(Ventas[Fecha], -12, MONTH)
)
```

### 6.2 Medidas de Crecimiento
```DAX
// Crecimiento % vs Año Anterior
Crecimiento % Año Anterior = 
DIVIDE(
    [Ventas Totales] - [Ventas Año Anterior],
    [Ventas Año Anterior],
    0
)

// Crecimiento % vs Mes Anterior
Crecimiento % Mes Anterior = 
DIVIDE(
    [Ventas Totales] - [Ventas Mes Anterior],
    [Ventas Mes Anterior],
    0
)

// Variación Absoluta vs Año Anterior
Variación Absoluta Año Anterior = 
[Ventas Totales] - [Ventas Año Anterior]

// Variación Absoluta vs Mes Anterior
Variación Absoluta Mes Anterior = 
[Ventas Totales] - [Ventas Mes Anterior]
```

### 6.3 Medidas de Tendencias
```DAX
// Promedio Móvil 3 Meses
Promedio Móvil 3M = 
AVERAGEX(
    DATESINPERIOD(
        Ventas[Fecha],
        LASTDATE(Ventas[Fecha]),
        -3,
        MONTH
    ),
    [Ventas Totales]
)

// Promedio Móvil 6 Meses
Promedio Móvil 6M = 
AVERAGEX(
    DATESINPERIOD(
        Ventas[Fecha],
        LASTDATE(Ventas[Fecha]),
        -6,
        MONTH
    ),
    [Ventas Totales]
)

// Ventas Acumuladas Año
Ventas Acumuladas Año = 
TOTALYTD(
    [Ventas Totales],
    Ventas[Fecha]
)
```

---

## 7. MEDIDAS DAX - CATEGORÍA: ANÁLISIS POR CANAL

### 7.1 Medidas por Canal
```DAX
// Ventas por Canal (Web)
Ventas Web = 
CALCULATE(
    [Ventas Totales],
    Ventas[Canal] = "Web"
)

// Ventas por Canal (App)
Ventas App = 
CALCULATE(
    [Ventas Totales],
    Ventas[Canal] = "App"
)

// Ventas por Canal (Redes)
Ventas Redes = 
CALCULATE(
    [Ventas Totales],
    Ventas[Canal] = "Redes"
)

// Participación % por Canal
Participación % Canal = 
DIVIDE(
    [Ventas Totales],
    CALCULATE([Ventas Totales], ALL(Ventas[Canal])),
    0
)
```

### 7.2 Medidas Comparativas de Canales
```DAX
// Margen por Canal
Margen % Canal = 
CALCULATE(
    [Margen %],
    VALUES(Ventas[Canal])
)

// Ticket Promedio por Canal
Ticket Promedio Canal = 
CALCULATE(
    [Ticket Promedio],
    VALUES(Ventas[Canal])
)
```

---

## 8. MEDIDAS DAX - CATEGORÍA: ANÁLISIS GEOGRÁFICO

### 8.1 Medidas por Ciudad
```DAX
// Ventas por Ciudad
Ventas por Ciudad = 
CALCULATE(
    [Ventas Totales],
    VALUES(Ventas[Ciudad])
)

// Participación % por Ciudad
Participación % Ciudad = 
DIVIDE(
    [Ventas Totales],
    CALCULATE([Ventas Totales], ALL(Ventas[Ciudad])),
    0
)

// Top 3 Ciudades
Top 3 Ciudades = 
VAR TopCiudades = 
    TOPN(
        3,
        SUMMARIZE(Ventas, Ventas[Ciudad], "Ventas", [Ventas Totales]),
        [Ventas], DESC
    )
RETURN
    CONCATENATEX(TopCiudades, Ventas[Ciudad], ", ")
```

---

## 9. MEDIDAS DAX - CATEGORÍA: ANÁLISIS DE PRODUCTOS

### 9.1 Medidas por Producto y Categoría
```DAX
// Ventas por Categoría
Ventas por Categoría = 
CALCULATE(
    [Ventas Totales],
    VALUES(Ventas[Categoria])
)

// Participación % por Categoría
Participación % Categoría = 
DIVIDE(
    [Ventas Totales],
    CALCULATE([Ventas Totales], ALL(Ventas[Categoria])),
    0
)

// Top 5 Productos
Top 5 Productos = 
VAR TopProductos = 
    TOPN(
        5,
        SUMMARIZE(Ventas, Ventas[Producto], "Ventas", [Ventas Totales]),
        [Ventas], DESC
    )
RETURN
    CONCATENATEX(TopProductos, Ventas[Producto], ", ")

// Productos Únicos Vendidos
Productos Únicos = 
DISTINCTCOUNT(Ventas[Producto])
```

### 9.2 Medidas de Rotación
```DAX
// Rotación de Inventario (simplificado)
Rotación Producto = 
DIVIDE(
    [Cantidad Total],
    DISTINCTCOUNT(Ventas[Producto]),
    0
)
```

---

## 10. MEDIDAS DAX - CATEGORÍA: SATISFACCIÓN DEL CLIENTE

### 10.1 Medidas de Calificación
```DAX
// Calificación Promedio
Calificación Promedio = 
AVERAGE(Ventas[CalificacionCliente])

// Calificación Promedio (solo registros válidos)
Calificación Promedio Válida = 
CALCULATE(
    AVERAGE(Ventas[CalificacionCliente]),
    Ventas[CalificacionCliente] >= 1,
    Ventas[CalificacionCliente] <= 5
)

// Distribución de Calificaciones
Calificaciones 5 Estrellas = 
CALCULATE(
    COUNTROWS(Ventas),
    Ventas[CalificacionCliente] = 5
)

Calificaciones 4 Estrellas = 
CALCULATE(
    COUNTROWS(Ventas),
    Ventas[CalificacionCliente] = 4
)

Calificaciones 3 Estrellas = 
CALCULATE(
    COUNTROWS(Ventas),
    Ventas[CalificacionCliente] = 3
)

Calificaciones 2 Estrellas = 
CALCULATE(
    COUNTROWS(Ventas),
    Ventas[CalificacionCliente] = 2
)

Calificaciones 1 Estrella = 
CALCULATE(
    COUNTROWS(Ventas),
    Ventas[CalificacionCliente] = 1
)

// % Clientes Satisfechos (4-5 estrellas)
% Clientes Satisfechos = 
DIVIDE(
    CALCULATE(
        COUNTROWS(Ventas),
        Ventas[CalificacionCliente] >= 4
    ),
    COUNTROWS(Ventas),
    0
)
```

---

## 11. MEDIDAS DAX - CATEGORÍA: ANÁLISIS DE DEVOLUCIONES

### 11.1 Medidas de Devoluciones
```DAX
// Total Devoluciones
Total Devoluciones = 
CALCULATE(
    SUM(Ventas[Cantidad]),
    Ventas[Cantidad] < 0
) * -1

// Valor Devoluciones
Valor Devoluciones = 
CALCULATE(
    [Ventas Totales],
    Ventas[Cantidad] < 0
) * -1

// Tasa de Devolución (%)
Tasa Devolución % = 
DIVIDE(
    ABS([Total Devoluciones]),
    [Cantidad Total] + ABS([Total Devoluciones]),
    0
)

// Número de Órdenes con Devolución
Órdenes con Devolución = 
CALCULATE(
    DISTINCTCOUNT(Ventas[OrderID]),
    Ventas[Cantidad] < 0
)
```

---

## 12. MEDIDAS DAX - CATEGORÍA: KPIs ESTRATÉGICOS

### 12.1 KPIs de Rendimiento
```DAX
// KPI: Objetivo de Ventas (ajustar según necesidad)
Objetivo Ventas = 500000

// % Cumplimiento Objetivo
% Cumplimiento Objetivo = 
DIVIDE(
    [Ventas Totales],
    [Objetivo Ventas],
    0
)

// KPI: Objetivo de Margen (ajustar según necesidad)
Objetivo Margen % = 0.30

// Desviación Margen
Desviación Margen = 
[Margen %] - [Objetivo Margen %]

// KPI: Objetivo de Calificación (ajustar según necesidad)
Objetivo Calificación = 4.0

// Desviación Calificación
Desviación Calificación = 
[Calificación Promedio Válida] - [Objetivo Calificación]
```

### 12.2 KPIs de Eficiencia
```DAX
// Ventas por Orden
Ventas por Orden = 
DIVIDE(
    [Ventas Totales],
    [Total Órdenes],
    0
)

// Utilidad por Orden
Utilidad por Orden = 
DIVIDE(
    [Utilidad Total],
    [Total Órdenes],
    0
)

// Eficiencia de Canal (Ventas/Órdenes)
Eficiencia Canal = 
DIVIDE(
    [Ventas Totales],
    [Total Órdenes],
    0
)
```

---

## 13. MEDIDAS DAX - CATEGORÍA: ANÁLISIS AVANZADO

### 13.1 Medidas de Concentración
```DAX
// Índice de Concentración (Top 20% productos)
Concentración Productos = 
VAR TotalVentas = [Ventas Totales]
VAR TopProductos = 
    TOPN(
        ROUNDUP(DISTINCTCOUNT(Ventas[Producto]) * 0.2, 0),
        SUMMARIZE(Ventas, Ventas[Producto], "Ventas", [Ventas Totales]),
        [Ventas], DESC
    )
VAR VentasTop = 
    SUMX(
        TopProductos,
        [Ventas]
    )
RETURN
    DIVIDE(VentasTop, TotalVentas, 0)
```

### 13.2 Medidas de Estacionalidad
```DAX
// Ventas Promedio por Mes
Ventas Promedio Mes = 
AVERAGEX(
    VALUES(Ventas[MesNombre]),
    [Ventas Totales]
)

// Variación Estacional
Variación Estacional = 
DIVIDE(
    [Ventas Totales] - [Ventas Promedio Mes],
    [Ventas Promedio Mes],
    0
)
```

---

## 14. VARIABLES DE MEDICIÓN PARA EL DASHBOARD

### 14.1 Tarjetas KPI Principales
1. **Ventas Totales** - [Ventas Totales Netas]
2. **Crecimiento %** - [Crecimiento % Año Anterior]
3. **Utilidad Total** - [Utilidad Neta]
4. **Margen %** - [Margen Neto %]
5. **Ticket Promedio** - [Ticket Promedio]
6. **Calificación Promedio** - [Calificación Promedio Válida]
7. **Total Órdenes** - [Total Órdenes Netas]
8. **Tasa Devolución** - [Tasa Devolución %]

### 14.2 Gráficos de Tendencias
- **Línea Temporal**: Ventas Totales por Mes (últimos 12 meses)
- **Línea Comparativa**: Ventas Actuales vs Año Anterior
- **Línea de Promedio Móvil**: Promedio Móvil 3M y 6M

### 14.3 Gráficos de Comparación
- **Barras Apiladas**: Ventas por Canal y Categoría
- **Barras Agrupadas**: Ventas por Ciudad
- **Barras Horizontales**: Top 10 Productos

### 14.4 Gráficos de Distribución
- **Donut/Pie**: Participación por Canal
- **Donut/Pie**: Participación por Categoría
- **Donut/Pie**: Distribución de Calificaciones

### 14.5 Tablas y Matrices
- **Tabla Detallada**: Ventas por Producto, Categoría, Canal
- **Matriz**: Ventas por Ciudad y Canal
- **Tabla de KPIs**: Comparación de métricas por período

---

## 15. FILTROS Y SEGMENTADORES RECOMENDADOS

### 15.1 Filtros de Nivel de Página
- **Rango de Fechas**: Fecha (desde/hasta)
- **Canal**: Web, App, Redes
- **Ciudad**: Todas las ciudades
- **Categoría**: Todas las categorías

### 15.2 Segmentadores Visuales
- **Período**: Mes, Trimestre, Año
- **Canal**: Botones o Dropdown
- **Ciudad**: Lista múltiple selección
- **Categoría**: Lista múltiple selección
- **Tipo Transacción**: Venta/Devolución

---

## 16. HIPÓTESIS INICIALES PARA VALIDAR

### 16.1 Hipótesis sobre Caída de Ventas
1. **H1**: Las ventas han disminuido principalmente en el canal Web
2. **H2**: La caída se concentra en productos de categoría Electrónica
3. **H3**: Ciudades específicas muestran mayor caída
4. **H4**: La calificación del cliente ha disminuido en los últimos meses
5. **H5**: El margen de utilidad se ha reducido por aumento de costos
6. **H6**: Las devoluciones han aumentado significativamente

### 16.2 Medidas para Validar Hipótesis
- Comparar [Ventas por Canal] entre períodos
- Analizar [Ventas por Categoría] con [Crecimiento % Año Anterior]
- Evaluar [Calificación Promedio] por mes
- Comparar [Margen %] histórico
- Analizar [Tasa Devolución %] por período

---

## 17. ORDEN DE IMPLEMENTACIÓN RECOMENDADO

### Fase 1: Preparación de Datos
1. Importar CSV en Power BI
2. Limpiar datos en Power Query
3. Crear columnas calculadas básicas (Ingreso, CostoTotal, Utilidad)
4. Crear columnas temporales (Año, Mes, Trimestre)

### Fase 2: Medidas Básicas
1. Ventas Totales
2. Costo Total
3. Utilidad Total
4. Margen %

### Fase 3: Medidas Temporales
1. Ventas Año Anterior
2. Crecimiento % Año Anterior
3. Promedio Móvil 3M

### Fase 4: Medidas por Dimensión
1. Medidas por Canal
2. Medidas por Ciudad
3. Medidas por Categoría

### Fase 5: Medidas Avanzadas
1. KPIs estratégicos
2. Medidas de satisfacción
3. Medidas de devoluciones

---

## 18. NOTAS IMPORTANTES

### 18.1 Consideraciones de Rendimiento
- Usar SUMX solo cuando sea necesario (para cálculos complejos)
- Preferir SUM para agregaciones simples
- Crear tablas de calendario separadas para análisis temporal avanzado

### 18.2 Mejores Prácticas
- Nombrar medidas de forma clara y consistente
- Agrupar medidas en carpetas en Power BI
- Documentar medidas complejas con comentarios
- Validar resultados con cálculos manuales

### 18.3 Validación de Datos
- Verificar que las sumas coincidan con el dataset original
- Validar porcentajes (deben sumar 100% en distribuciones)
- Revisar que las fechas estén en el rango correcto
- Confirmar que no haya divisiones por cero

---

## 19. ESTRUCTURA DE CARPETAS EN POWER BI (RECOMENDADA)

```
Medidas/
├── Ventas/
│   ├── Ventas Totales
│   ├── Ventas Totales Netas
│   ├── Ticket Promedio
│   └── Total Órdenes
├── Rentabilidad/
│   ├── Utilidad Total
│   ├── Margen %
│   └── Costo Total
├── Temporal/
│   ├── Ventas Año Anterior
│   ├── Crecimiento % Año Anterior
│   └── Promedio Móvil 3M
├── Por Canal/
│   ├── Ventas Web
│   ├── Ventas App
│   └── Ventas Redes
├── Por Geografía/
│   └── Ventas por Ciudad
├── Por Producto/
│   ├── Ventas por Categoría
│   └── Top 5 Productos
├── Cliente/
│   ├── Calificación Promedio
│   └── % Clientes Satisfechos
└── KPIs/
    ├── % Cumplimiento Objetivo
    └── Desviación Margen
```

---

## 20. PRÓXIMOS PASOS

1. ✅ **Completado**: Definición de todas las métricas y variables
2. ⏭️ **Siguiente**: Importar y limpiar datos en Power BI
3. ⏭️ **Siguiente**: Crear columnas calculadas
4. ⏭️ **Siguiente**: Implementar medidas DAX básicas
5. ⏭️ **Siguiente**: Construir visualizaciones del dashboard
6. ⏭️ **Siguiente**: Validar hipótesis y generar insights

---

**Documento creado para facilitar la implementación del dashboard en Power BI**
**Fecha**: 2025
**Proyecto**: Coquito Amarillo - Sistema de Visualización Estratégica
