"""
Script para generar datos del dashboard en formato JavaScript
"""
import pandas as pd
import json

# Leer datos limpios
df = pd.read_csv('df_ventas_limpiado.csv', encoding='utf-8-sig')

# Guardar datos originales completos para filtrado
df_original = df.copy()

# Filtrar solo ventas (excluir devoluciones)
df_ventas = df[df['Cantidad'] > 0].copy()

# Calcular estadísticas de productos
productos = df_ventas.groupby('Producto').agg({
    'Ingreso': 'sum',
    'Utilidad': 'sum',
    'Cantidad': 'sum',
    'OrderID': 'count'
}).reset_index()

productos['Margen'] = (productos['Utilidad'] / productos['Ingreso'] * 100).round(2)
productos = productos.sort_values('Ingreso', ascending=False)
productos['Categoria'] = productos['Producto'].map(
    df_ventas.groupby('Producto')['Categoria'].first()
)

# Calcular estadísticas por categoría
categorias = df_ventas.groupby('Categoria').agg({
    'Ingreso': 'sum',
    'Utilidad': 'sum'
}).reset_index()

# Calcular estadísticas por canal
canales = df_ventas.groupby('Canal').agg({
    'Ingreso': 'sum'
}).reset_index().sort_values('Ingreso', ascending=False)

# Calcular estadísticas por ciudad
ciudades = df_ventas.groupby('Ciudad').agg({
    'Ingreso': 'sum'
}).reset_index().sort_values('Ingreso', ascending=False)

# Calcular estadísticas por segmento de cliente
segmentos = df_ventas.groupby('SegmentoCliente').agg({
    'Ingreso': 'sum',
    'OrderID': 'count'
}).reset_index()

# Calcular estadísticas por rango de precio
rangos = df_ventas.groupby('RangoPrecio').agg({
    'Ingreso': 'sum'
}).reset_index()

# Calcular estadísticas generales
ventas_totales = float(df_ventas['Ingreso'].sum())
utilidad_total = float(df_ventas['Utilidad'].sum())
margen_promedio = float((utilidad_total / ventas_totales * 100)) if ventas_totales > 0 else 0
total_ordenes = int(df_ventas['OrderID'].nunique())
ticket_promedio = float(ventas_totales / total_ordenes) if total_ordenes > 0 else 0

stats = {
    'ventas_totales': ventas_totales,
    'utilidad_total': utilidad_total,
    'margen_promedio': round(margen_promedio, 2),
    'total_ordenes': total_ordenes,
    'ticket_promedio': round(ticket_promedio, 2)
}

# Preparar datos para JavaScript
dashboard_data = {
    'productos': productos.to_dict('records'),
    'categorias': categorias.to_dict('records'),
    'canales': canales.to_dict('records'),
    'ciudades': ciudades.to_dict('records'),
    'segmentos': segmentos.to_dict('records'),
    'rangos': rangos.to_dict('records'),
    'stats': stats,
    'datos_originales': df_ventas.to_dict('records')  # Datos completos para filtrado
}

# Generar archivo JavaScript
js_content = f"""
// Datos del dashboard generados automáticamente
(function() {{
    const dashboardData = {json.dumps(dashboard_data, indent=2, ensure_ascii=False)};
    
    // Hacer disponible globalmente
    window.dashboardData = dashboardData;
    
    // Si el dashboard ya está cargado, actualizarlo
    if (typeof window.updateDashboard === 'function') {{
        window.updateDashboard();
    }} else {{
        // Esperar a que el dashboard se cargue
        if (document.readyState === 'loading') {{
            document.addEventListener('DOMContentLoaded', function() {{
                if (typeof window.loadData === 'function') {{
                    window.loadData();
                }}
            }});
        }} else {{
            // Ya está cargado
            if (typeof window.loadData === 'function') {{
                window.loadData();
            }}
        }}
    }}
}})();
"""

# Guardar archivo JavaScript
with open('generate_dashboard_data.js', 'w', encoding='utf-8') as f:
    f.write(js_content)

print("[OK] Archivo generate_dashboard_data.js generado exitosamente")
print(f"[INFO] Productos procesados: {len(productos)}")
print(f"[INFO] Ventas totales: ${ventas_totales:,.2f}")
print(f"[INFO] Utilidad total: ${utilidad_total:,.2f}")
print(f"[INFO] Margen promedio: {margen_promedio:.2f}%")
