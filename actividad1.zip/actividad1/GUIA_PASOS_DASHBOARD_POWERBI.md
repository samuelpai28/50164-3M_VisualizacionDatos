# Guía Paso a Paso: Crear Dashboard en Power BI
## Empresa: Coquito Amarillo - Área de Comercio Electrónico

---

## FASE 1: PREPARACIÓN Y CONFIGURACIÓN INICIAL

### Paso 1.1: Abrir Power BI Desktop
1. Abre **Power BI Desktop**
2. Si aparece la pantalla de inicio, haz clic en **"Obtener datos"** o **"Cerrar"**

### Paso 1.2: Importar el Dataset Limpio
1. En la cinta superior, haz clic en **"Obtener datos"** → **"Más..."**
2. Selecciona **"Texto/CSV"** o busca "CSV" en el buscador
3. Navega hasta la carpeta: `C:\Users\Windows\Desktop\visualizacion de datos`
4. Selecciona el archivo **`df_ventas_limpiado.csv`**
5. Haz clic en **"Abrir"**
6. En la ventana de vista previa, verifica que los datos se vean correctos
7. Haz clic en **"Cargar"** (o "Transformar datos" si quieres revisar primero)

### Paso 1.3: Verificar Tipos de Datos
1. En el panel izquierdo, haz clic en el icono de **"Vista de datos"** (icono de tabla)
2. Verifica que las columnas tengan los tipos correctos:
   - **OrderID**: Número entero
   - **Fecha**: Fecha/hora
   - **Ciudad, Canal, Producto, Categoria**: Texto
   - **Cantidad**: Número entero
   - **PrecioUnitario, CostoUnitario**: Número decimal
   - **CalificacionCliente**: Número entero
   - **Ingreso, CostoTotal, Utilidad, UtilidadPorUnidad**: Número decimal
   - **Año, Mes**: Número entero
   - **AñoMes, Trimestre, DíaSemana, MesNombre**: Texto
   - **TipoTransaccion, SegmentoCliente, RangoPrecio**: Texto

3. Si alguna columna tiene el tipo incorrecto:
   - Haz clic derecho en la columna → **"Cambiar tipo"** → Selecciona el tipo correcto

---

## FASE 2: CREAR COLUMNAS CALCULADAS (Si no están en el CSV)

### Paso 2.1: Verificar Columnas Calculadas
1. Verifica que el CSV ya tenga estas columnas (deberían estar en `df_ventas_limpiado.csv`):
   - Ingreso
   - CostoTotal
   - Utilidad
   - UtilidadPorUnidad
   - Año, Mes, AñoMes, Trimestre, DíaSemana, MesNombre
   - TipoTransaccion
   - SegmentoCliente
   - RangoPrecio

2. Si alguna falta, créala:
   - Clic derecho en la tabla "df_ventas_limpiado" → **"Nueva columna"**
   - Usa las fórmulas del documento `METRICAS_Y_VARIABLES_POWERBI.md`

---

## FASE 3: CREAR MEDIDAS DAX BÁSICAS

### Paso 3.1: Organizar Medidas en Carpetas
1. En el panel de campos (derecha), haz clic derecho en la tabla "df_ventas_limpiado"
2. Selecciona **"Nueva carpeta"**
3. Crea las siguientes carpetas:
   - `01_Ventas`
   - `02_Rentabilidad`
   - `03_Temporal`
   - `04_Por_Canal`
   - `05_Por_Geografia`
   - `06_Por_Producto`
   - `07_Cliente`
   - `08_Devoluciones`
   - `09_KPIs`

### Paso 3.2: Crear Medidas Básicas de Ventas
1. Clic derecho en la tabla "df_ventas_limpiado" → **"Nueva medida"**
2. **Nombre**: `Ventas Totales`
3. **Carpeta**: `01_Ventas`
4. **Fórmula**:
```DAX
Ventas Totales = 
SUMX(
    'df_ventas_limpiado',
    'df_ventas_limpiado'[Cantidad] * 'df_ventas_limpiado'[PrecioUnitario]
)
```

5. Repite el proceso para estas medidas (copia desde `MEDIDAS_DAX_LISTAS.txt`):
   - `Ventas Totales Netas`
   - `Cantidad Total`
   - `Total Órdenes`
   - `Total Órdenes Netas`
   - `Ticket Promedio`

### Paso 3.3: Crear Medidas de Rentabilidad
1. Crea las siguientes medidas en la carpeta `02_Rentabilidad`:
   - `Costo Total`
   - `Costo Total Neto`
   - `Utilidad Total`
   - `Utilidad Neta`
   - `Margen %`
   - `Margen Neto %`

### Paso 3.4: Crear Medidas Temporales
1. Crea las siguientes medidas en la carpeta `03_Temporal`:
   - `Ventas Año Anterior`
   - `Ventas Mes Anterior`
   - `Crecimiento % Año Anterior`
   - `Crecimiento % Mes Anterior`
   - `Variación Absoluta Año Anterior`
   - `Promedio Móvil 3M`

**Nota**: Para medidas temporales, asegúrate de tener una tabla de calendario. Si no la tienes:
- Ve a **"Modelado"** → **"Nueva tabla"**
- Fórmula: `Calendario = CALENDAR(MIN('df_ventas_limpiado'[Fecha]), MAX('df_ventas_limpiado'[Fecha]))`
- Crea relación entre `Calendario[Fecha]` y `df_ventas_limpiado[Fecha]`

### Paso 3.5: Crear Medidas por Dimensión
1. **Por Canal** (carpeta `04_Por_Canal`):
   - `Ventas Web`
   - `Ventas App`
   - `Ventas Redes`
   - `Participación % Canal`

2. **Por Geografía** (carpeta `05_Por_Geografia`):
   - `Ventas por Ciudad`
   - `Participación % Ciudad`

3. **Por Producto** (carpeta `06_Por_Producto`):
   - `Ventas por Categoría`
   - `Participación % Categoría`
   - `Top 5 Productos`

4. **Cliente** (carpeta `07_Cliente`):
   - `Calificación Promedio Válida`
   - `% Clientes Satisfechos`

5. **Devoluciones** (carpeta `08_Devoluciones`):
   - `Total Devoluciones`
   - `Tasa Devolución %`

6. **KPIs** (carpeta `09_KPIs`):
   - `Objetivo Ventas` (ajusta el valor según necesidad)
   - `% Cumplimiento Objetivo`
   - `Objetivo Margen %`
   - `Desviación Margen`

---

## FASE 4: DISEÑAR EL DASHBOARD

### Paso 4.1: Crear Páginas del Dashboard
1. En la parte inferior, haz clic en el **"+"** para crear nuevas páginas
2. Renombra las páginas:
   - **Página 1**: "Resumen Ejecutivo"
   - **Página 2**: "Análisis Temporal"
   - **Página 3**: "Análisis por Canal"
   - **Página 4**: "Análisis Geográfico"
   - **Página 5**: "Análisis de Productos"
   - **Página 6**: "Satisfacción del Cliente"

### Paso 4.2: Configurar Tema y Formato
1. Ve a **"Vista"** → **"Temas"** → Selecciona un tema o crea uno personalizado
2. Configura colores corporativos si es necesario

---

## FASE 5: CONSTRUIR PÁGINA 1 - RESUMEN EJECUTIVO

### Paso 5.1: Crear Tarjetas KPI
1. En el panel de visualizaciones, selecciona **"Tarjeta"**
2. Arrastra al lienzo y configura:
   - **Campos**: `Ventas Totales Netas`
   - **Formato**: Moneda ($)
   - **Título**: "Ventas Totales"
   - Ajusta tamaño y posición

3. Repite para crear más tarjetas:
   - **Tarjeta 2**: `Crecimiento % Año Anterior` (Formato: Porcentaje)
   - **Tarjeta 3**: `Utilidad Neta` (Formato: Moneda)
   - **Tarjeta 4**: `Margen Neto %` (Formato: Porcentaje)
   - **Tarjeta 5**: `Ticket Promedio` (Formato: Moneda)
   - **Tarjeta 6**: `Calificación Promedio Válida` (Formato: Decimal)
   - **Tarjeta 7**: `Total Órdenes Netas` (Formato: Número)
   - **Tarjeta 8**: `Tasa Devolución %` (Formato: Porcentaje)

4. Organiza las tarjetas en una cuadrícula (2 filas x 4 columnas)

### Paso 5.2: Crear Gráfico de Líneas - Tendencias
1. Selecciona **"Gráfico de líneas"**
2. Configura:
   - **Eje X**: `Fecha` (o `AñoMes` para agrupación mensual)
   - **Eje Y**: `Ventas Totales Netas`
   - **Leyenda**: `Canal` (opcional, para comparar canales)
   - **Título**: "Tendencia de Ventas por Mes"

3. Formato:
   - Aumenta el tamaño de fuente del título
   - Ajusta colores de las líneas

### Paso 5.3: Crear Gráfico de Barras - Top Productos
1. Selecciona **"Gráfico de barras agrupadas"**
2. Configura:
   - **Eje Y**: `Producto`
   - **Eje X**: `Ventas Totales Netas`
   - **Ordenar por**: `Ventas Totales Netas` (descendente)
   - **Filtro visual**: Top 10
   - **Título**: "Top 10 Productos por Ventas"

### Paso 5.4: Crear Gráfico de Donut - Participación por Canal
1. Selecciona **"Gráfico de anillo"**
2. Configura:
   - **Leyenda**: `Canal`
   - **Valores**: `Ventas Totales Netas`
   - **Título**: "Participación de Ventas por Canal"

### Paso 5.5: Crear Gráfico de Barras - Ventas por Categoría
1. Selecciona **"Gráfico de barras apiladas"**
2. Configura:
   - **Eje X**: `Categoria`
   - **Eje Y**: `Ventas Totales Netas`
   - **Leyenda**: `Canal` (para ver distribución por canal)
   - **Título**: "Ventas por Categoría y Canal"

### Paso 5.6: Agregar Segmentadores (Filtros)
1. Selecciona **"Segmentador"**
2. Arrastra al lienzo y configura:
   - **Campo**: `Fecha`
   - **Tipo**: Entre (para rango de fechas)
   - **Título**: "Rango de Fechas"

3. Crea más segmentadores:
   - **Segmentador 2**: `Canal` (Tipo: Lista)
   - **Segmentador 3**: `Ciudad` (Tipo: Lista, selección múltiple)
   - **Segmentador 4**: `Categoria` (Tipo: Lista, selección múltiple)

4. Configura los segmentadores para que afecten a todas las visualizaciones de la página

---

## FASE 6: CONSTRUIR PÁGINA 2 - ANÁLISIS TEMPORAL

### Paso 6.1: Gráfico de Líneas - Comparación Año Actual vs Año Anterior
1. Selecciona **"Gráfico de líneas"**
2. Configura:
   - **Eje X**: `AñoMes`
   - **Eje Y**: `Ventas Totales Netas`
   - **Leyenda**: Crea una medida calculada para comparar años
   - **Título**: "Comparación: Año Actual vs Año Anterior"

### Paso 6.2: Gráfico de Columnas - Crecimiento Mensual
1. Selecciona **"Gráfico de columnas agrupadas"**
2. Configura:
   - **Eje X**: `MesNombre`
   - **Eje Y**: `Crecimiento % Mes Anterior`
   - **Título**: "Crecimiento Mensual (%)"
   - **Formato**: Colores condicionales (verde para positivo, rojo para negativo)

### Paso 6.3: Gráfico de Líneas - Promedio Móvil
1. Selecciona **"Gráfico de líneas"**
2. Configura:
   - **Eje X**: `Fecha`
   - **Eje Y**: `Promedio Móvil 3M`
   - **Título**: "Tendencia con Promedio Móvil (3 meses)"

### Paso 6.4: Tabla - Resumen por Mes
1. Selecciona **"Tabla"**
2. Agrega columnas:
   - `MesNombre`
   - `Ventas Totales Netas`
   - `Utilidad Neta`
   - `Margen Neto %`
   - `Crecimiento % Mes Anterior`
   - `Total Órdenes Netas`
   - `Ticket Promedio`

3. Formato:
   - Aplica formato condicional a `Crecimiento % Mes Anterior`
   - Ordena por `MesNombre`

---

## FASE 7: CONSTRUIR PÁGINA 3 - ANÁLISIS POR CANAL

### Paso 7.1: Tarjetas KPI por Canal
1. Crea 3 tarjetas:
   - **Tarjeta 1**: `Ventas Web` (Título: "Ventas Web")
   - **Tarjeta 2**: `Ventas App` (Título: "Ventas App")
   - **Tarjeta 3**: `Ventas Redes` (Título: "Ventas Redes")

### Paso 7.2: Gráfico de Barras - Comparación de Canales
1. Selecciona **"Gráfico de barras agrupadas"**
2. Configura:
   - **Eje X**: `Canal`
   - **Eje Y**: `Ventas Totales Netas`
   - **Título**: "Ventas por Canal"

### Paso 7.3: Gráfico de Líneas - Tendencias por Canal
1. Selecciona **"Gráfico de líneas"**
2. Configura:
   - **Eje X**: `AñoMes`
   - **Eje Y**: `Ventas Totales Netas`
   - **Leyenda**: `Canal`
   - **Título**: "Evolución de Ventas por Canal"

### Paso 7.4: Matriz - Métricas por Canal
1. Selecciona **"Matriz"**
2. Configura:
   - **Filas**: `Canal`
   - **Valores**:
     - `Ventas Totales Netas`
     - `Utilidad Neta`
     - `Margen Neto %`
     - `Ticket Promedio Canal`
     - `Total Órdenes Netas`

---

## FASE 8: CONSTRUIR PÁGINA 4 - ANÁLISIS GEOGRÁFICO

### Paso 8.1: Gráfico de Barras - Ventas por Ciudad
1. Selecciona **"Gráfico de barras agrupadas"**
2. Configura:
   - **Eje Y**: `Ciudad`
   - **Eje X**: `Ventas Totales Netas`
   - **Ordenar por**: `Ventas Totales Netas` (descendente)
   - **Título**: "Ventas por Ciudad"

### Paso 8.2: Gráfico de Donut - Participación por Ciudad
1. Selecciona **"Gráfico de anillo"**
2. Configura:
   - **Leyenda**: `Ciudad`
   - **Valores**: `Ventas Totales Netas`
   - **Título**: "Participación de Ventas por Ciudad"

### Paso 8.3: Matriz - Ventas por Ciudad y Canal
1. Selecciona **"Matriz"**
2. Configura:
   - **Filas**: `Ciudad`
   - **Columnas**: `Canal`
   - **Valores**: `Ventas Totales Netas`
   - **Título**: "Ventas por Ciudad y Canal"

---

## FASE 9: CONSTRUIR PÁGINA 5 - ANÁLISIS DE PRODUCTOS

### Paso 9.1: Gráfico de Barras - Ventas por Categoría
1. Selecciona **"Gráfico de barras agrupadas"**
2. Configura:
   - **Eje X**: `Categoria`
   - **Eje Y**: `Ventas Totales Netas`
   - **Título**: "Ventas por Categoría"

### Paso 9.2: Tabla - Top Productos
1. Selecciona **"Tabla"**
2. Configura:
   - **Columnas**:
     - `Producto`
     - `Categoria`
     - `Ventas Totales Netas`
     - `Utilidad Neta`
     - `Margen Neto %`
   - **Filtro visual**: Top 20 por `Ventas Totales Netas`
   - **Título**: "Top 20 Productos"

### Paso 9.3: Gráfico de Treemap - Distribución de Ventas
1. Selecciona **"Gráfico de árbol"**
2. Configura:
   - **Grupo**: `Categoria`
   - **Valores**: `Ventas Totales Netas`
   - **Título**: "Distribución de Ventas por Categoría"

---

## FASE 10: CONSTRUIR PÁGINA 6 - SATISFACCIÓN DEL CLIENTE

### Paso 10.1: Tarjeta - Calificación Promedio
1. Crea una tarjeta grande:
   - **Campo**: `Calificación Promedio Válida`
   - **Formato**: Decimal (1 decimal)
   - **Título**: "Calificación Promedio"

### Paso 10.2: Gráfico de Columnas - Distribución de Calificaciones
1. Selecciona **"Gráfico de columnas agrupadas"**
2. Configura:
   - **Eje X**: `CalificacionCliente`
   - **Eje Y**: `Total Órdenes` (o COUNT de registros)
   - **Título**: "Distribución de Calificaciones"

### Paso 10.3: Gráfico de Donut - Segmentación de Clientes
1. Selecciona **"Gráfico de anillo"**
2. Configura:
   - **Leyenda**: `SegmentoCliente`
   - **Valores**: `Total Órdenes`
   - **Título**: "Segmentación de Clientes por Satisfacción"

### Paso 10.4: Gráfico de Líneas - Evolución de Calificación
1. Selecciona **"Gráfico de líneas"**
2. Configura:
   - **Eje X**: `AñoMes`
   - **Eje Y**: `Calificación Promedio Válida`
   - **Título**: "Evolución de Calificación Promedio"

---

## FASE 11: CONFIGURAR FILTROS Y NAVEGACIÓN

### Paso 11.1: Configurar Filtros a Nivel de Página
1. En cada página, ve al panel de **"Filtros"** (icono de embudo)
2. Arrastra campos al área de **"Filtros en esta página"**:
   - `Fecha` (Tipo: Entre)
   - `Canal`
   - `Ciudad`
   - `Categoria`

### Paso 11.2: Crear Navegación entre Páginas
1. Ve a **"Insertar"** → **"Botones"** → **"Tipo"**
2. Crea botones de navegación en cada página:
   - Botón "Resumen Ejecutivo"
   - Botón "Análisis Temporal"
   - Botón "Análisis por Canal"
   - Botón "Análisis Geográfico"
   - Botón "Análisis de Productos"
   - Botón "Satisfacción del Cliente"

3. Para cada botón:
   - **Acción**: Navegar a página
   - **Destino**: Selecciona la página correspondiente

### Paso 11.3: Agregar Títulos y Textos
1. **"Insertar"** → **"Texto"** → **"Cuadro de texto"**
2. Agrega títulos descriptivos en cada página
3. Agrega notas o conclusiones donde sea necesario

---

## FASE 12: FORMATO Y DISEÑO FINAL

### Paso 12.1: Aplicar Formato Consistente
1. Selecciona todas las visualizaciones de una página
2. Aplica formato consistente:
   - **Fuente**: Arial o Calibri
   - **Tamaño de título**: 14-16pt
   - **Colores**: Usa una paleta consistente
   - **Bordes**: Aplica bordes sutiles

### Paso 12.2: Alinear y Distribuir Visualizaciones
1. Usa las herramientas de alineación en **"Vista"** → **"Mostrar cuadrícula"**
2. Alinea visualizaciones para un diseño profesional

### Paso 12.3: Agregar Formato Condicional
1. En tablas y matrices, aplica formato condicional:
   - **Escala de colores** para valores numéricos
   - **Iconos** para indicadores de rendimiento
   - **Barras de datos** para comparaciones visuales

---

## FASE 13: VALIDACIÓN Y PRUEBAS

### Paso 13.1: Validar Cálculos
1. Verifica que las medidas calculen correctamente:
   - Compara con cálculos manuales
   - Verifica que los totales coincidan

### Paso 13.2: Probar Filtros
1. Prueba todos los segmentadores y filtros
2. Verifica que las visualizaciones se actualicen correctamente

### Paso 13.3: Revisar Rendimiento
1. Si el dashboard es lento:
   - Optimiza medidas DAX
   - Reduce el número de visualizaciones por página
   - Considera usar agregaciones

---

## FASE 14: GUARDAR Y PUBLICAR

### Paso 14.1: Guardar el Archivo
1. **Archivo** → **"Guardar"**
2. Nombra el archivo: `Dashboard_Coquito_Amarillo.pbix`
3. Guarda en la carpeta del proyecto

### Paso 14.2: Publicar en Power BI Service (Opcional)
1. **Inicio** → **"Publicar"**
2. Selecciona el workspace
3. Espera a que se complete la publicación

---

## CHECKLIST FINAL

Antes de considerar el dashboard completo, verifica:

- [ ] Todas las medidas DAX están creadas y funcionando
- [ ] Todas las páginas tienen visualizaciones
- [ ] Los filtros funcionan correctamente
- [ ] La navegación entre páginas funciona
- [ ] Los formatos son consistentes
- [ ] Los títulos son claros y descriptivos
- [ ] Las visualizaciones tienen sentido para el análisis
- [ ] El dashboard responde a las hipótesis planteadas
- [ ] El archivo está guardado
- [ ] Se ha probado con diferentes filtros

---

## TIPS Y MEJORES PRÁCTICAS

1. **Rendimiento**:
   - Limita el número de visualizaciones por página (máximo 6-8)
   - Usa medidas calculadas en lugar de columnas calculadas cuando sea posible

2. **Diseño**:
   - Mantén un diseño limpio y profesional
   - Usa colores con propósito (no solo decorativos)
   - Asegúrate de que el texto sea legible

3. **Usabilidad**:
   - Agrega tooltips informativos
   - Usa iconos para mejorar la comprensión
   - Incluye instrucciones si es necesario

4. **Análisis**:
   - Asegúrate de que cada visualización responda una pregunta de negocio
   - Valida las hipótesis con los datos
   - Documenta hallazgos importantes

---

## RECURSOS ADICIONALES

- **Documento de Métricas**: `METRICAS_Y_VARIABLES_POWERBI.md`
- **Medidas DAX Listas**: `MEDIDAS_DAX_LISTAS.txt`
- **Dataset Limpio**: `df_ventas_limpiado.csv`
- **Reporte de Calidad**: `reporte_calidad_datos.txt`

---

**¡Éxito con tu dashboard!**
