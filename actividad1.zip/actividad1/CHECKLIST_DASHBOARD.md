# Checklist Rápido - Dashboard Power BI
## Coquito Amarillo - Comercio Electrónico

---

## ✅ FASE 1: PREPARACIÓN (15 minutos)

- [ ] Abrir Power BI Desktop
- [ ] Importar `df_ventas_limpiado.csv`
- [ ] Verificar tipos de datos de todas las columnas
- [ ] Verificar que existan las columnas calculadas:
  - [ ] Ingreso
  - [ ] CostoTotal
  - [ ] Utilidad
  - [ ] Año, Mes, AñoMes, Trimestre
  - [ ] TipoTransaccion
  - [ ] SegmentoCliente

---

## ✅ FASE 2: MEDIDAS DAX (30-45 minutos)

### Carpeta: 01_Ventas
- [ ] Ventas Totales
- [ ] Ventas Totales Netas
- [ ] Cantidad Total
- [ ] Total Órdenes
- [ ] Total Órdenes Netas
- [ ] Ticket Promedio

### Carpeta: 02_Rentabilidad
- [ ] Costo Total
- [ ] Utilidad Total
- [ ] Utilidad Neta
- [ ] Margen %
- [ ] Margen Neto %

### Carpeta: 03_Temporal
- [ ] Ventas Año Anterior
- [ ] Crecimiento % Año Anterior
- [ ] Variación Absoluta Año Anterior
- [ ] Promedio Móvil 3M

### Carpeta: 04_Por_Canal
- [ ] Ventas Web
- [ ] Ventas App
- [ ] Ventas Redes
- [ ] Participación % Canal

### Carpeta: 05_Por_Geografia
- [ ] Ventas por Ciudad
- [ ] Participación % Ciudad

### Carpeta: 06_Por_Producto
- [ ] Ventas por Categoría
- [ ] Participación % Categoría

### Carpeta: 07_Cliente
- [ ] Calificación Promedio Válida
- [ ] % Clientes Satisfechos

### Carpeta: 08_Devoluciones
- [ ] Total Devoluciones
- [ ] Tasa Devolución %

### Carpeta: 09_KPIs
- [ ] Objetivo Ventas (ajustar valor)
- [ ] % Cumplimiento Objetivo
- [ ] Objetivo Margen %
- [ ] Desviación Margen

---

## ✅ FASE 3: PÁGINA 1 - RESUMEN EJECUTIVO

### Tarjetas KPI (8 tarjetas)
- [ ] Ventas Totales Netas
- [ ] Crecimiento % Año Anterior
- [ ] Utilidad Neta
- [ ] Margen Neto %
- [ ] Ticket Promedio
- [ ] Calificación Promedio Válida
- [ ] Total Órdenes Netas
- [ ] Tasa Devolución %

### Visualizaciones
- [ ] Gráfico de líneas: Tendencia de Ventas por Mes
- [ ] Gráfico de barras: Top 10 Productos
- [ ] Gráfico de donut: Participación por Canal
- [ ] Gráfico de barras apiladas: Ventas por Categoría y Canal

### Filtros
- [ ] Segmentador: Rango de Fechas
- [ ] Segmentador: Canal
- [ ] Segmentador: Ciudad
- [ ] Segmentador: Categoría

---

## ✅ FASE 4: PÁGINA 2 - ANÁLISIS TEMPORAL

- [ ] Gráfico de líneas: Comparación Año Actual vs Año Anterior
- [ ] Gráfico de columnas: Crecimiento Mensual (%)
- [ ] Gráfico de líneas: Promedio Móvil 3M
- [ ] Tabla: Resumen por Mes (con 7 columnas)

---

## ✅ FASE 5: PÁGINA 3 - ANÁLISIS POR CANAL

- [ ] 3 Tarjetas: Ventas Web, App, Redes
- [ ] Gráfico de barras: Comparación de Canales
- [ ] Gráfico de líneas: Evolución de Ventas por Canal
- [ ] Matriz: Métricas por Canal

---

## ✅ FASE 6: PÁGINA 4 - ANÁLISIS GEOGRÁFICO

- [ ] Gráfico de barras: Ventas por Ciudad
- [ ] Gráfico de donut: Participación por Ciudad
- [ ] Matriz: Ventas por Ciudad y Canal

---

## ✅ FASE 7: PÁGINA 5 - ANÁLISIS DE PRODUCTOS

- [ ] Gráfico de barras: Ventas por Categoría
- [ ] Tabla: Top 20 Productos
- [ ] Gráfico de treemap: Distribución de Ventas

---

## ✅ FASE 8: PÁGINA 6 - SATISFACCIÓN DEL CLIENTE

- [ ] Tarjeta grande: Calificación Promedio
- [ ] Gráfico de columnas: Distribución de Calificaciones
- [ ] Gráfico de donut: Segmentación de Clientes
- [ ] Gráfico de líneas: Evolución de Calificación

---

## ✅ FASE 9: NAVEGACIÓN Y FILTROS

- [ ] Botones de navegación en cada página
- [ ] Filtros a nivel de página configurados
- [ ] Filtros funcionan correctamente

---

## ✅ FASE 10: FORMATO Y DISEÑO

- [ ] Formato consistente en todas las páginas
- [ ] Títulos claros y descriptivos
- [ ] Colores coherentes
- [ ] Visualizaciones alineadas
- [ ] Formato condicional aplicado donde corresponde

---

## ✅ FASE 11: VALIDACIÓN

- [ ] Todas las medidas calculan correctamente
- [ ] Los totales coinciden con el dataset
- [ ] Los filtros actualizan todas las visualizaciones
- [ ] La navegación funciona entre páginas
- [ ] No hay errores en las visualizaciones

---

## ✅ FASE 12: GUARDAR Y FINALIZAR

- [ ] Archivo guardado como `Dashboard_Coquito_Amarillo.pbix`
- [ ] Revisión final del dashboard completo
- [ ] Documentación de hallazgos importantes

---

## 📊 ORDEN RECOMENDADO DE TRABAJO

1. **Primero**: Crear todas las medidas DAX (Fase 2)
2. **Segundo**: Construir Página 1 - Resumen Ejecutivo (Fase 3)
3. **Tercero**: Agregar las demás páginas una por una
4. **Cuarto**: Configurar navegación y filtros
5. **Quinto**: Aplicar formato y diseño final
6. **Sexto**: Validar y probar todo

---

## ⚠️ PROBLEMAS COMUNES Y SOLUCIONES

### Error: "No se puede determinar un único valor"
- **Solución**: Usa funciones de agregación (SUM, AVERAGE, etc.) en las medidas

### Error: "La columna no existe"
- **Solución**: Verifica que el nombre de la tabla y columna sea exacto (case-sensitive)

### Visualizaciones no se actualizan con filtros
- **Solución**: Verifica que los filtros estén configurados para "Filtros en esta página"

### Medidas temporales no funcionan
- **Solución**: Crea una tabla de calendario y establece la relación con la tabla de ventas

---

## 📝 NOTAS RÁPIDAS

- **Tiempo estimado total**: 4-6 horas
- **Archivos necesarios**: `df_ventas_limpiado.csv`, `MEDIDAS_DAX_LISTAS.txt`
- **Referencia completa**: `GUIA_PASOS_DASHBOARD_POWERBI.md`

---

**¡Buena suerte con tu dashboard!** 🚀
