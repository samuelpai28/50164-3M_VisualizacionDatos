"""
Script de Análisis y Limpieza de Datos para Power BI
Empresa: Coquito Amarillo - Área de Comercio Electrónico
"""

import pandas as pd
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configuración
ARCHIVO_ORIGINAL = 'df_ventas.csv'
ARCHIVO_LIMPIO = 'df_ventas_limpiado.csv'
ARCHIVO_REPORTE = 'reporte_calidad_datos.txt'

import sys
import io

# Configurar salida UTF-8 para Windows
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("=" * 80)
print("ANALISIS Y LIMPIEZA DE DATOS - COQUITO AMARILLO")
print("=" * 80)

# 1. CARGAR DATOS
print("\n1. CARGANDO DATOS...")
df = pd.read_csv(ARCHIVO_ORIGINAL)
print(f"   [OK] Registros cargados: {len(df):,}")

# 2. ANÁLISIS INICIAL
print("\n2. ANÁLISIS INICIAL DE DATOS...")
print(f"   - Columnas: {list(df.columns)}")
print(f"   - Forma del dataset: {df.shape}")

# 3. IDENTIFICAR PROBLEMAS DE CALIDAD
print("\n3. IDENTIFICANDO PROBLEMAS DE CALIDAD...")

problemas = {
    'fechas_inconsistentes': 0,
    'precios_nulos': 0,
    'costos_error': 0,
    'calificaciones_error': 0,
    'cantidades_negativas': 0,
    'categoria_inconsistente': 0
}

# Analizar fechas
print("\n   a) Análisis de Fechas:")
fechas_parseadas = []
for idx, fecha in enumerate(df['Fecha']):
    try:
        # Intentar formato YYYY-MM-DD
        if isinstance(fecha, str) and len(fecha) == 10 and fecha[4] == '-':
            pd.to_datetime(fecha, format='%Y-%m-%d')
            fechas_parseadas.append(True)
        # Intentar formato MM/DD/YYYY
        elif isinstance(fecha, str) and '/' in fecha:
            pd.to_datetime(fecha, format='%m/%d/%Y')
            fechas_parseadas.append(True)
            problemas['fechas_inconsistentes'] += 1
        else:
            fechas_parseadas.append(False)
    except:
        fechas_parseadas.append(False)

print(f"      - Fechas en formato inconsistente: {problemas['fechas_inconsistentes']}")

# Analizar precios nulos
problemas['precios_nulos'] = df['PrecioUnitario'].isna().sum()
print(f"\n   b) Análisis de Precios:")
print(f"      - Precios nulos: {problemas['precios_nulos']}")

# Analizar costos con ERROR_SYS
problemas['costos_error'] = (df['CostoUnitario'] == 'ERROR_SYS').sum() if 'ERROR_SYS' in df['CostoUnitario'].values else 0
print(f"\n   c) Análisis de Costos:")
print(f"      - Costos con ERROR_SYS: {problemas['costos_error']}")

# Analizar calificaciones con ERROR_SYS
problemas['calificaciones_error'] = (df['CalificacionCliente'] == 'ERROR_SYS').sum() if 'ERROR_SYS' in df['CalificacionCliente'].values else 0
print(f"\n   d) Análisis de Calificaciones:")
print(f"      - Calificaciones con ERROR_SYS: {problemas['calificaciones_error']}")

# Analizar cantidades negativas
problemas['cantidades_negativas'] = (df['Cantidad'] < 0).sum()
print(f"\n   e) Análisis de Cantidades:")
print(f"      - Cantidades negativas (devoluciones): {problemas['cantidades_negativas']}")

# Analizar categorías inconsistentes
problemas['categoria_inconsistente'] = (df['Categoria'] == 'Elec').sum()
print(f"\n   f) Análisis de Categorías:")
print(f"      - Categorías 'Elec' (debe ser 'Electrónica'): {problemas['categoria_inconsistente']}")

# 4. LIMPIEZA DE DATOS
print("\n4. LIMPIANDO DATOS...")
df_limpiado = df.copy()

# Limpiar fechas
print("   a) Estandarizando fechas...")
def limpiar_fecha(fecha):
    try:
        if isinstance(fecha, str):
            # Formato YYYY-MM-DD
            if len(fecha) == 10 and fecha[4] == '-':
                return pd.to_datetime(fecha, format='%Y-%m-%d')
            # Formato MM/DD/YYYY
            elif '/' in fecha:
                return pd.to_datetime(fecha, format='%m/%d/%Y')
        return pd.to_datetime(fecha)
    except:
        return pd.NaT

df_limpiado['Fecha'] = df_limpiado['Fecha'].apply(limpiar_fecha)
fechas_invalidas = df_limpiado['Fecha'].isna().sum()
print(f"      [OK] Fechas estandarizadas. Fechas invalidas: {fechas_invalidas}")

# Limpiar precios nulos (reemplazar con promedio por categoría)
print("   b) Limpiando precios nulos...")
if problemas['precios_nulos'] > 0:
    precio_promedio_categoria = df_limpiado.groupby('Categoria')['PrecioUnitario'].transform('mean')
    df_limpiado['PrecioUnitario'] = df_limpiado['PrecioUnitario'].fillna(precio_promedio_categoria)
    # Si aún hay nulos, usar promedio general
    precio_promedio_general = df_limpiado['PrecioUnitario'].mean()
    df_limpiado['PrecioUnitario'] = df_limpiado['PrecioUnitario'].fillna(precio_promedio_general)
    print(f"      [OK] Precios nulos reemplazados con promedio por categoria")

# Limpiar costos con ERROR_SYS
print("   c) Limpiando costos con ERROR_SYS...")
if problemas['costos_error'] > 0:
    # Convertir a numérico, reemplazando ERROR_SYS con NaN
    df_limpiado['CostoUnitario'] = pd.to_numeric(df_limpiado['CostoUnitario'], errors='coerce')
    # Reemplazar NaN con promedio por categoría
    costo_promedio_categoria = df_limpiado.groupby('Categoria')['CostoUnitario'].transform('mean')
    df_limpiado['CostoUnitario'] = df_limpiado['CostoUnitario'].fillna(costo_promedio_categoria)
    print(f"      [OK] Costos con ERROR_SYS reemplazados con promedio por categoria")

# Limpiar calificaciones con ERROR_SYS
print("   d) Limpiando calificaciones con ERROR_SYS...")
if problemas['calificaciones_error'] > 0:
    # Convertir a numérico, reemplazando ERROR_SYS con NaN
    df_limpiado['CalificacionCliente'] = pd.to_numeric(df_limpiado['CalificacionCliente'], errors='coerce')
    # Reemplazar con 3 (neutral)
    df_limpiado['CalificacionCliente'] = df_limpiado['CalificacionCliente'].fillna(3)
    print(f"      [OK] Calificaciones con ERROR_SYS reemplazadas con 3 (neutral)")

# Corregir categorías inconsistentes
print("   e) Corrigiendo categorías inconsistentes...")
if problemas['categoria_inconsistente'] > 0:
    df_limpiado['Categoria'] = df_limpiado['Categoria'].replace('Elec', 'Electrónica')
    print(f"      [OK] Categorias 'Elec' reemplazadas por 'Electronica'")

# 5. CREAR COLUMNAS CALCULADAS
print("\n5. CREANDO COLUMNAS CALCULADAS...")

# Asegurar que las columnas numéricas sean del tipo correcto
df_limpiado['Cantidad'] = pd.to_numeric(df_limpiado['Cantidad'], errors='coerce')
df_limpiado['PrecioUnitario'] = pd.to_numeric(df_limpiado['PrecioUnitario'], errors='coerce')
df_limpiado['CostoUnitario'] = pd.to_numeric(df_limpiado['CostoUnitario'], errors='coerce')

# Ingreso
df_limpiado['Ingreso'] = df_limpiado['Cantidad'] * df_limpiado['PrecioUnitario']
print("   [OK] Columna 'Ingreso' creada")

# CostoTotal
df_limpiado['CostoTotal'] = df_limpiado['Cantidad'] * df_limpiado['CostoUnitario']
print("   [OK] Columna 'CostoTotal' creada")

# Utilidad
df_limpiado['Utilidad'] = df_limpiado['Ingreso'] - df_limpiado['CostoTotal']
print("   [OK] Columna 'Utilidad' creada")

# UtilidadPorUnidad
df_limpiado['UtilidadPorUnidad'] = df_limpiado['PrecioUnitario'] - df_limpiado['CostoUnitario']
print("   [OK] Columna 'UtilidadPorUnidad' creada")

# Columnas temporales
df_limpiado['Año'] = df_limpiado['Fecha'].dt.year
df_limpiado['Mes'] = df_limpiado['Fecha'].dt.month
df_limpiado['AñoMes'] = df_limpiado['Fecha'].dt.to_period('M').astype(str)
df_limpiado['Trimestre'] = 'Q' + df_limpiado['Fecha'].dt.quarter.astype(str) + ' ' + df_limpiado['Fecha'].dt.year.astype(str)
df_limpiado['DíaSemana'] = df_limpiado['Fecha'].dt.day_name()
df_limpiado['MesNombre'] = df_limpiado['Fecha'].dt.month_name()
print("   [OK] Columnas temporales creadas")

# TipoTransaccion
df_limpiado['TipoTransaccion'] = df_limpiado['Cantidad'].apply(lambda x: 'Devolucion' if x < 0 else 'Venta')
print("   [OK] Columna 'TipoTransaccion' creada")

# SegmentoCliente
def segmentar_cliente(calificacion):
    if pd.isna(calificacion):
        return "Sin Calificación"
    elif calificacion >= 4.5:
        return "Muy Satisfecho"
    elif calificacion >= 3.5:
        return "Satisfecho"
    elif calificacion >= 2.5:
        return "Neutral"
    elif calificacion >= 1.5:
        return "Insatisfecho"
    else:
        return "Muy Insatisfecho"

df_limpiado['SegmentoCliente'] = df_limpiado['CalificacionCliente'].apply(segmentar_cliente)
print("   [OK] Columna 'SegmentoCliente' creada")

# RangoPrecio
def rango_precio(precio):
    if pd.isna(precio):
        return "Sin Precio"
    elif precio >= 500:
        return "Alto"
    elif precio >= 100:
        return "Medio"
    elif precio >= 50:
        return "Bajo"
    else:
        return "Muy Bajo"

df_limpiado['RangoPrecio'] = df_limpiado['PrecioUnitario'].apply(rango_precio)
print("   [OK] Columna 'RangoPrecio' creada")

# 6. ESTADÍSTICAS RESUMEN
print("\n6. GENERANDO ESTADÍSTICAS RESUMEN...")

# Eliminar registros con fechas inválidas para estadísticas
df_stats = df_limpiado[df_limpiado['Fecha'].notna()].copy()

ventas_totales = df_stats[df_stats['Cantidad'] > 0]['Ingreso'].sum()
ventas_con_devoluciones = df_stats['Ingreso'].sum()
utilidad_total = df_stats[df_stats['Cantidad'] > 0]['Utilidad'].sum()
margen = (utilidad_total / ventas_totales * 100) if ventas_totales > 0 else 0
total_ordenes = df_stats['OrderID'].nunique()
ticket_promedio = ventas_totales / total_ordenes if total_ordenes > 0 else 0
calificacion_promedio = df_stats['CalificacionCliente'].mean()

print(f"\n   ESTADÍSTICAS PRINCIPALES:")
print(f"   - Ventas Totales (netas): ${ventas_totales:,.2f}")
print(f"   - Utilidad Total: ${utilidad_total:,.2f}")
print(f"   - Margen %: {margen:.2f}%")
print(f"   - Total Órdenes: {total_ordenes:,}")
print(f"   - Ticket Promedio: ${ticket_promedio:,.2f}")
print(f"   - Calificación Promedio: {calificacion_promedio:.2f}")

# 7. GUARDAR ARCHIVO LIMPIO
print("\n7. GUARDANDO ARCHIVO LIMPIO...")
df_limpiado.to_csv(ARCHIVO_LIMPIO, index=False, encoding='utf-8-sig')
print(f"   [OK] Archivo guardado: {ARCHIVO_LIMPIO}")

# 8. GENERAR REPORTE
print("\n8. GENERANDO REPORTE DE CALIDAD...")
with open(ARCHIVO_REPORTE, 'w', encoding='utf-8') as f:
    f.write("=" * 80 + "\n")
    f.write("REPORTE DE CALIDAD DE DATOS - COQUITO AMARILLO\n")
    f.write("=" * 80 + "\n\n")
    
    f.write("RESUMEN DE PROBLEMAS IDENTIFICADOS:\n")
    f.write("-" * 80 + "\n")
    f.write(f"Fechas en formato inconsistente: {problemas['fechas_inconsistentes']}\n")
    f.write(f"Precios nulos: {problemas['precios_nulos']}\n")
    f.write(f"Costos con ERROR_SYS: {problemas['costos_error']}\n")
    f.write(f"Calificaciones con ERROR_SYS: {problemas['calificaciones_error']}\n")
    f.write(f"Cantidades negativas (devoluciones): {problemas['cantidades_negativas']}\n")
    f.write(f"Categorías inconsistentes: {problemas['categoria_inconsistente']}\n")
    f.write(f"Fechas inválidas después de limpieza: {fechas_invalidas}\n\n")
    
    f.write("ESTADÍSTICAS PRINCIPALES:\n")
    f.write("-" * 80 + "\n")
    f.write(f"Ventas Totales (netas): ${ventas_totales:,.2f}\n")
    f.write(f"Utilidad Total: ${utilidad_total:,.2f}\n")
    f.write(f"Margen %: {margen:.2f}%\n")
    f.write(f"Total Órdenes: {total_ordenes:,}\n")
    f.write(f"Ticket Promedio: ${ticket_promedio:,.2f}\n")
    f.write(f"Calificación Promedio: {calificacion_promedio:.2f}\n\n")
    
    f.write("DISTRIBUCIÓN POR CANAL:\n")
    f.write("-" * 80 + "\n")
    ventas_por_canal = df_stats[df_stats['Cantidad'] > 0].groupby('Canal')['Ingreso'].sum()
    for canal, ventas in ventas_por_canal.items():
        porcentaje = (ventas / ventas_totales * 100) if ventas_totales > 0 else 0
        f.write(f"{canal}: ${ventas:,.2f} ({porcentaje:.2f}%)\n")
    f.write("\n")
    
    f.write("DISTRIBUCIÓN POR CATEGORÍA:\n")
    f.write("-" * 80 + "\n")
    ventas_por_categoria = df_stats[df_stats['Cantidad'] > 0].groupby('Categoria')['Ingreso'].sum()
    for categoria, ventas in ventas_por_categoria.items():
        porcentaje = (ventas / ventas_totales * 100) if ventas_totales > 0 else 0
        f.write(f"{categoria}: ${ventas:,.2f} ({porcentaje:.2f}%)\n")
    f.write("\n")
    
    f.write("DISTRIBUCIÓN POR CIUDAD:\n")
    f.write("-" * 80 + "\n")
    ventas_por_ciudad = df_stats[df_stats['Cantidad'] > 0].groupby('Ciudad')['Ingreso'].sum()
    for ciudad, ventas in ventas_por_ciudad.items():
        porcentaje = (ventas / ventas_totales * 100) if ventas_totales > 0 else 0
        f.write(f"{ciudad}: ${ventas:,.2f} ({porcentaje:.2f}%)\n")
    f.write("\n")
    
    f.write("RANGO DE FECHAS:\n")
    f.write("-" * 80 + "\n")
    f.write(f"Fecha mínima: {df_stats['Fecha'].min()}\n")
    f.write(f"Fecha maxima: {df_stats['Fecha'].max()}\n")
    f.write(f"Periodo: {(df_stats['Fecha'].max() - df_stats['Fecha'].min()).days} dias\n")

print(f"   [OK] Reporte guardado: {ARCHIVO_REPORTE}")

print("\n" + "=" * 80)
print("PROCESO COMPLETADO EXITOSAMENTE")
print("=" * 80)
print(f"\nArchivos generados:")
print(f"  1. {ARCHIVO_LIMPIO} - Dataset limpio listo para Power BI")
print(f"  2. {ARCHIVO_REPORTE} - Reporte de calidad de datos")
print("\nProximos pasos:")
print("  1. Revisar el reporte de calidad")
print("  2. Importar 'df_ventas_limpiado.csv' en Power BI")
print("  3. Crear las medidas DAX usando el archivo MEDIDAS_DAX_LISTAS.txt")
print("  4. Construir el dashboard segun el diseno propuesto")
